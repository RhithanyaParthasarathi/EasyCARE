document.addEventListener('DOMContentLoaded', function() {
    // Get references to the buttons
    //const appointmentSchedulerButton = document.getElementById('appointment-scheduler');
    const virtualDoctorButton = document.getElementById('virtual-doctor');
    const medicationHistoryButton = document.getElementById('medication-history');
    const healthDataButton = document.getElementById('health-data');
    const viewPrescriptionButton = document.getElementById('view-prescription');
    const pharmacyButton = document.getElementById('pharmacy');


    // Add click event listeners to each button
    //appointmentSchedulerButton.addEventListener('click', function(event) {
    //    event.preventDefault(); // Prevent the div acting like a link
    //    alert('Navigating to Appointment Scheduler (Not Implemented)');
    //});


    //virtualDoctorButton.addEventListener('click', function(event) {
      //  event.preventDefault();
        //alert('Navigating to Virtual Doctor (Not Implemented)');
    //});


     //medicationHistoryButton.addEventListener('click', function(event) {
       // event.preventDefault();
       // alert('Navigating to Medication History (Not Implemented)');
    //});


    //healthDataButton.addEventListener('click', function(event) {
      //  event.preventDefault();
        //alert('Navigating to Health Data (Not Implemented)');
    //});


     //viewPrescriptionButton.addEventListener('click', function(event) {
       // event.preventDefault();
        //alert('Navigating to View Prescription (Not Implemented)');
    //});


    //pharmacyButton.addEventListener('click', function(event) {
      //  event.preventDefault();
        //alert('Navigating to Pharmacy (Not Implemented)');
    //});
});